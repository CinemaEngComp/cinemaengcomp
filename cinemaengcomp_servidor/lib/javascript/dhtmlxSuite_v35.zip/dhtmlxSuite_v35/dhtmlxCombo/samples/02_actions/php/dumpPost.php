<?php
echo "<pre>"; print_r($_POST); echo "</pre>"; die();
?>
